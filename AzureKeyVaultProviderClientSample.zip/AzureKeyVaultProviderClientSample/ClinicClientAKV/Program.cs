﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
// Adding for Azure Key Vault provider
using System.Configuration;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.SqlServer.Management.AlwaysEncrypted.AzureKeyVaultProvider;


namespace AlwaysEncryptedDemo
{
    /// <summary>
    /// A simple program to demonstrate querying the database using Always Encrypted and a column master key stored in Azure Key Vault.
    /// </summary>
    class Program
    {
        private static SqlConnection _sqlconn;
        private static ClientCredential _clientCredential;

        public static void Main(string[] args)
        {
            InitializeAzureKeyVaultProvider();
            string myconnection = ConfigurationManager.AppSettings["DatabaseConnectionString"];

            //_sqlconn = new SqlConnection(ConfigurationManager.AppSettings["DatabaseConnectionString"]);
            _sqlconn = new SqlConnection(myconnection);

            try
            {
                _sqlconn.Open();

                // Let's try (heh) a few things.
                // Note that, as far as the client app is concerned, all data is in plaintext

                // Add a couple rows to the table
                AddNewPatient("123-45-6789", "John", "Doe", new DateTime(1875, 04, 04));
                AddNewPatient("562-00-6354", "Michael", "Park", new DateTime(1928, 11, 18));

                // Look up a specific patient by their encrypted SSN
                Console.WriteLine("Looking up a specific patient by SSN...");
                FindAndPrintPatientInformation("123-45-6789");

                // Print all patients
                Console.WriteLine("Printing all patient information");
                FindAndPrintPatientInformation();
            }
            finally
            {
                _sqlconn.Close();
            }

            Console.WriteLine("Press any key to close.");
            Console.ReadKey();
        }

        /// <summary>
        /// Initializes and registers the Azure Key Vault key store provider with ADO.net
        /// </summary>
        static void InitializeAzureKeyVaultProvider()
        {
            string clientId = ConfigurationManager.AppSettings["AuthClientId"];
            string clientSecret = ConfigurationManager.AppSettings["AuthClientSecret"];
            _clientCredential = new ClientCredential(clientId, clientSecret);

            // Direct the provider to the authentication delegate
            SqlColumnEncryptionAzureKeyVaultProvider azureKeyVaultProvider = new SqlColumnEncryptionAzureKeyVaultProvider(GetToken);

            Dictionary<string, SqlColumnEncryptionKeyStoreProvider> providers = new Dictionary<string, SqlColumnEncryptionKeyStoreProvider>();
            providers.Add(SqlColumnEncryptionAzureKeyVaultProvider.ProviderName, azureKeyVaultProvider);

            // register the provider with ADO.net
            SqlConnection.RegisterColumnEncryptionKeyStoreProviders(providers);
        }

        /// <summary>
        /// A callback to redeem the application id/key for a token for Azure Key Vault
        /// </summary>
        public async static Task<string> GetToken(string authority, string resource, string scope)
        {
            var authContext = new AuthenticationContext(authority);
            ClientCredential clientCred = new ClientCredential("b0b2a0df-b409-43cf-906f-6723ce471527", "pLmhNzQVB0H93TCNoG3OYQs3WPUYbkHJFVZ6YjRo3Xs=");

            AuthenticationResult result = await authContext.AcquireTokenAsync(resource, clientCred);

            if (result == null)
                throw new InvalidOperationException("Failed to obtain the JWT token");

            return result.AccessToken;
        }

        /// <summary>
        /// Insert a row for a new patient.
        /// </summary>
        /// <param name="ssn">Patient's SSN</param>
        /// <param name="firstName">Patient's first name</param>
        /// <param name="lastName">Patient's last name</param>
        /// <param name="birthdate">Patient's date of bith</param>
        private static void AddNewPatient(string ssn, string firstName, string lastName, DateTime birthdate)
        {
            SqlCommand cmd = _sqlconn.CreateCommand();

            // Use parameterized SQL to insert the data

            cmd.CommandText = @"INSERT INTO [dbo].[Patients] ([SSN], [FirstName], [LastName], [BirthDate]) VALUES (@SSN, @FirstName, @LastName, @BirthDate);";

            SqlParameter paramSSN = cmd.CreateParameter();
            paramSSN.ParameterName = @"@SSN";
            paramSSN.SqlDbType = SqlDbType.Char;
            paramSSN.DbType = DbType.AnsiStringFixedLength;
            paramSSN.Direction = ParameterDirection.Input;
            paramSSN.Value = ssn;
            paramSSN.Size = 11;
            cmd.Parameters.Add(paramSSN);

            SqlParameter paramFirstName = cmd.CreateParameter();
            paramFirstName.ParameterName = @"@FirstName";
            paramFirstName.DbType = DbType.String;
            paramFirstName.Direction = ParameterDirection.Input;
            paramFirstName.Value = firstName;
            paramFirstName.Size = 50;
            cmd.Parameters.Add(paramFirstName);

            SqlParameter paramLastName = cmd.CreateParameter();
            paramLastName.ParameterName = @"@LastName";
            paramLastName.DbType = DbType.String;
            paramLastName.Direction = ParameterDirection.Input;
            paramLastName.Value = lastName;
            paramLastName.Size = 50;
            cmd.Parameters.Add(paramLastName);

            SqlParameter paramBirthdate = cmd.CreateParameter();
            paramBirthdate.ParameterName = @"@BirthDate";
            paramBirthdate.SqlDbType = SqlDbType.Date;
            paramBirthdate.Direction = ParameterDirection.Input;
            paramBirthdate.Value = birthdate;
            cmd.Parameters.Add(paramBirthdate);

            cmd.ExecuteNonQuery();
        }

        /// <summary>
        /// Query the DB to find the patient with the desired SSN, and print the data in the console
        /// </summary>
        /// <param name="ssn">Patient's SSN</param>
        private static void FindAndPrintPatientInformation(string ssn = null)
        {
            SqlDataReader reader = null;
            try
            {
                reader = ConstructAndRunQuery(ssn);
                PrintPatientInformation(reader);
            }
            finally
            {
                if (reader != null)
                    reader.Close();
            }
        }

        /// <summary>
        /// Implementation for querying a single patient, based on SSN
        /// </summary>
        /// <param name="ssn">Patient's SSN</param>
        /// <returns>A datareader with the query resultset</returns>
        private static SqlDataReader ConstructAndRunQuery(string ssn = null)
        {
            SqlCommand cmd = _sqlconn.CreateCommand();

            // Use parameterized SQL to query the data

            cmd.CommandText = @"SELECT [SSN], [FirstName], [LastName], [BirthDate] FROM [dbo].[Patients]";

            if (!String.IsNullOrWhiteSpace(ssn))
            {
                cmd.CommandText += " WHERE [SSN] = @SSN";

                SqlParameter paramSSN = cmd.CreateParameter();
                paramSSN.ParameterName = @"@SSN";
                paramSSN.DbType = DbType.AnsiStringFixedLength;
                paramSSN.Direction = ParameterDirection.Input;
                paramSSN.Value = ssn;
                paramSSN.Size = 11;
                cmd.Parameters.Add(paramSSN);
            } 

            SqlDataReader reader = cmd.ExecuteReader();
            return reader;
        }

        /// <summary>
        /// Format and print the patient data in the console.
        /// </summary>
        /// <param name="reader">the rowset with the patient's data</param>
        private static void PrintPatientInformation(SqlDataReader reader)
        {
            string breaker = new string('-', (19 * 4) + 9);
            Console.WriteLine();
            Console.WriteLine(breaker);
            Console.WriteLine(@"| {0,15} |  {1,15} |  {2,15} | {3,25} |", reader.GetName(0), reader.GetName(1), reader.GetName(2), reader.GetName(3));

            while (reader.Read())
            {
                Console.WriteLine(breaker);
                Console.WriteLine(@"| {0,15} |  {1,15} |  {2,15} | {3,25} | ", reader[0], reader[1], reader[2], ((DateTime)reader[3]).ToLongDateString());
            }
                
            Console.WriteLine(breaker);
            Console.WriteLine();
            Console.WriteLine();
        }
    }
}
